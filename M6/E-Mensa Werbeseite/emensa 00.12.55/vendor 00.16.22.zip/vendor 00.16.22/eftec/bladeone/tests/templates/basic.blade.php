It is a basic template {{$variable}}.
