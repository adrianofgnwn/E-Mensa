@table(values=$countries alias="alias")
@row()
@row2()
@endtable
