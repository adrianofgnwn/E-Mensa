paramlessmyglobal:{!! $myglobal !!}{!! $slot !!}
