it is test 1
@one(a1="hola" a2="mundo")

two:@two(1,2,3)
