<h1> layout.blade.php</h1>
{{ $header }}<br>
@yield('content')
{{ $footer }}<br>