<?php

use eftec\bladeone\BladeOneLang;

/**
 * @see \myBlade is defined on /BladeOne/examples/testlang.php
 */
myBlade::$dictionary=array(
    'Hat'=>'Sombrero'
    ,'Cat'=>'Gato'
    ,'Cats'=>'Gatos' // plural
    ,'%s is a nice cat'=>'%s es un buen gato'
);
