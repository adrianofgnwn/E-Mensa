<?php
// it is the example.

$flag=true; // It is only a flag for the example

include "../../examplerelative.php";