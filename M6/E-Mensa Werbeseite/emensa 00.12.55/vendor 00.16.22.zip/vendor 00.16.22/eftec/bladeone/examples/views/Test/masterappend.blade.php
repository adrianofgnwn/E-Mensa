<hr>
<h1>v2 it is the header</h1>
<hr>
<hr>sidebar
@section('sidebar')
    <b style="background-color: cadetblue"> its the parent of the siderbar</b>
@show
<hr>content
@section('content')
    <b style="background-color: cadetblue"> its the parent of the siderbar2</b>
@show
<hr>