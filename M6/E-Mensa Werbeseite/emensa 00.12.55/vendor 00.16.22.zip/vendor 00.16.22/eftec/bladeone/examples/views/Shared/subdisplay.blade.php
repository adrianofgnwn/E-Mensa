<div style="background-color: lightgreen; margin-left: 100px">
    <br>
    Global variable :{{$g1}} {{$g2}}<br>
    Scope variable :{{$s1 | "s1 is not defined"}} {{$s2 | "s2 is not defined"}}<br>
    <br>
</div>