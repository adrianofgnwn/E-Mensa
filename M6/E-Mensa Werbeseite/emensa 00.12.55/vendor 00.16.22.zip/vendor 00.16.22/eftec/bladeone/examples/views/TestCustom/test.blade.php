<html>
<style>
    .panel { background-color: lightblue}
    .panel-heading { background-color: blue}
    .panel-body { background-color: darkblue}

</style>


@panel('Title')
some content
@endpanel
</html>