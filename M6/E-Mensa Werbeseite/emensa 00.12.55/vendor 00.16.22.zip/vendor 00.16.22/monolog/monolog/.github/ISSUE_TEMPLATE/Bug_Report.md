---
name: Bug Report
about: Create a bug report
labels: Bug
---

Monolog version 1|2|3?

Write your bug report here.
