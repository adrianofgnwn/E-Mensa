---
name: Feature
about: Suggest a new feature or enhancement
labels: Feature
---

Write your suggestion here.
