<div style="background-color: yellow">
**The fottermissing is missing {{$other}} {{myfunction()}} **
</div>