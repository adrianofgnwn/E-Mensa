<div class="alert alert-danger" style="; padding-left: 100px; border: black 1px solid">
    <div>PARAMLESS (colorless)</div>
    <div>myglobal:{!! $myglobal !!}</div>
    {!! $slot !!}
</div>
<br>