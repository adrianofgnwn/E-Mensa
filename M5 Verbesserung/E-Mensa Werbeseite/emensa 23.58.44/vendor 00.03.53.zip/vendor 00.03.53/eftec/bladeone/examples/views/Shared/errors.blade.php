<div style="background-color: lightcoral">
    <br>
It is an error {{$title}}<br>
    <br>
</div>