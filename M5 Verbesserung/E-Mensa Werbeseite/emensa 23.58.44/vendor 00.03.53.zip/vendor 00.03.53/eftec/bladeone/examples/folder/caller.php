<?php

include '../example_extends.php';
