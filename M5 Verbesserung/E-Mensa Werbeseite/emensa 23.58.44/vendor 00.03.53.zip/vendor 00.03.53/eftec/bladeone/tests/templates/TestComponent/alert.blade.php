color:{!! $color  !!},title:{!! $title !!},myglobal:{!! $myglobal !!}{!! $slot !!},end title:{!! $title !!}
