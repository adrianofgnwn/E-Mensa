{{--
  Lorem ipsum dolor @foreach
--}}
Multi line comment in PHP tags

@php
    /**
     * Lorem ipsum dolor @foreach
     */
@endphp
Single line comment in PHP tags

@php
    // Lorem ipsum dolor @foreach
@endphp
