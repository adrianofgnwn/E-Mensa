@component('TestComponent.paramless')
    CONTENTSLOT
@endcomponent
@component('TestComponent.alert',array('title'=>'no title','color'=>'red'))
    CONTENTSLOT2
@endcomponent
