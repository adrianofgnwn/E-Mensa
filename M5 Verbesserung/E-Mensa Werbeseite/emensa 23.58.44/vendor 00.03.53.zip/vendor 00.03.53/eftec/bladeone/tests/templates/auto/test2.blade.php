@table(values=$countries alias="alias")
row:
@row()
row2:
@row2()
@endtable
