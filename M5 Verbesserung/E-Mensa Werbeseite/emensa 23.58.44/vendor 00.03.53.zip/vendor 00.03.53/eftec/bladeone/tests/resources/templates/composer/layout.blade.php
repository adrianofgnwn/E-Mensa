*layout.blade.php*
{{ $header }}
@yield('content')
{{ $footer }}